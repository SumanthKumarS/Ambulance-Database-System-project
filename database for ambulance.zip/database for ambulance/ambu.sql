-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 31, 2021 at 05:37 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ambu`
--

-- --------------------------------------------------------

--
-- Table structure for table `patient_details`
--

CREATE TABLE `patient_details` (
  `patient_id` int(255) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `place` varchar(255) DEFAULT NULL,
  `date_time` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `patient_details`
--

INSERT INTO `patient_details` (`patient_id`, `name`, `email`, `phone`, `address`, `place`, `date_time`) VALUES
(1, 'abcd', 'abc@gmail.com', '7894562311', 'mandar', '12.9719	77.5937', '12/29/20	20:53:53'),
(2, 'xyzz', 'xyz@gmail.com', '9874563210', '', '12.9719	77.5937', '12/29/20	22:15:04'),
(3, 'abcd', 'abc@gmail.com', '7894562311', 'mandar', '12.971977.5937', '12/30/2007:17:54'),
(4, 'abcd', 'abc@gmail.com', '7894562311', 'mandar', '12.971977.5937', '12/30/2007:41:16');

-- --------------------------------------------------------

--
-- Table structure for table `request_accept`
--

CREATE TABLE `request_accept` (
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `reqst_accept` varchar(255) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `request_details`
--

CREATE TABLE `request_details` (
  `id` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `reqst_accept` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `time` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `request_details`
--

INSERT INTO `request_details` (`id`, `name`, `email`, `latitude`, `longitude`, `state`, `city`, `reqst_accept`, `date`, `time`) VALUES
('1', 'abcd', 'abc@gmail.com', '12.9719', '77.5937', 'Karnataka', 'Bengaluru', 'Requesting for Ambulance', NULL, NULL),
('2', 'sumanth kumar s', 'sum@gmail.com', '12.9719', '77.5937', 'Karnataka', 'Bengaluru', 'Reject', NULL, NULL),
('1', 'abcd', 'abc@gmail.com', '12.9719', '77.5937', 'Karnataka', 'Bengaluru', 'Requesting for Ambulance', NULL, NULL),
('3', 'abc', 'abc@gmail.com', '12.9719', '77.5937', 'Karnataka', 'Bengaluru', 'Accepted', NULL, NULL),
('1', 'abcd', 'abc@gmail.com', '12.9719', '77.5937', 'Karnataka', 'Bengaluru', 'Requesting for Ambulance', '0000-00-00', '16:55:54'),
('3', 'abc', 'abc@gmail.com', '12.9719', '77.5937', 'Karnataka', 'Bengaluru', 'Accepted', '0000-00-00', '17:07:31'),
('1', 'abcd', 'abc@gmail.com', '12.9719', '77.5937', 'Karnataka', 'Bengaluru', 'Requesting for Ambulance', '0000-00-00', '19:52:04'),
('2', 'sumanth kumar s', 'sum@gmail.com', '12.9719', '77.5937', 'Karnataka', 'Bengaluru', 'Accepted', '0000-00-00', '19:53:20'),
('2', 'xyzz', 'xyz@gmail.com', '12.9719', '77.5937', 'Karnataka', 'Bengaluru', 'Requesting for Ambulance', '0000-00-00', '22:13:12'),
('3', 'abc', 'abc@gmail.com', '12.9719', '77.5937', 'Karnataka', 'Bengaluru', 'Accepted', '0000-00-00', '22:13:52'),
('1', 'abcd', 'abc@gmail.com', '12.9719', '77.5937', 'Karnataka', 'Bengaluru', 'Requesting for Ambulance', '0000-00-00', '07:13:49'),
('2', 'sumanth kumar s', 'sum@gmail.com', '12.9719', '77.5937', 'Karnataka', 'Bengaluru', 'Accepted', '0000-00-00', '07:16:27'),
('1', 'abcd', 'abc@gmail.com', '12.9719', '77.5937', 'Karnataka', 'Bengaluru', 'Requesting for Ambulance', '0000-00-00', '07:23:59'),
('3', 'abc', 'abc@gmail.com', '12.9719', '77.5937', 'Karnataka', 'Bengaluru', 'Accepted', '0000-00-00', '07:37:09'),
('1', 'abcd', 'abc@gmail.com', '12.9719', '77.5937', 'Karnataka', 'Bengaluru', 'Requesting for Ambulance', '0000-00-00', '07:41:27'),
('3', 'abc', 'abc@gmail.com', '12.9719', '77.5937', 'Karnataka', 'Bengaluru', 'Reject', '0000-00-00', '07:49:12');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(255) NOT NULL,
  `f_name` varchar(255) DEFAULT NULL,
  `l_name` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `dob` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `f_name`, `l_name`, `phone`, `email`, `dob`, `gender`, `password`) VALUES
(1, 'abcd', '', '7894562311', 'abc@gmail.com', '4/2/2000', 'male', '456'),
(2, 'xyz', 'z', '9874563210', 'xyz@gmail.com', '12/3/2000', 'Female', '553'),
(3, 'a', 'a', 'a', 'asn@gnai@@123.com', '12-23-2000', 'Female', 'a'),
(16, 'a', 'a', 'a', 'a', 'a', 'Male', 'a'),
(17, 'a', '', '9784561230', 'ah@gmail.com', '2000-03-20', 'Female', '123');

-- --------------------------------------------------------

--
-- Table structure for table `user_info`
--

CREATE TABLE `user_info` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `dob` varchar(255) NOT NULL,
  `gender` enum('male','female','others') NOT NULL,
  `address` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_info`
--

INSERT INTO `user_info` (`id`, `name`, `phone`, `email`, `dob`, `gender`, `address`) VALUES
(1, 'abcd', '7894562311', 'abc@gmail.com', '4/2/2000', 'male', 'mandar'),
(2, 'xyzz', '9874563210', 'xyz@gmail.com', '12/3/2000', 'female', ''),
(5, 'dndns', '5955955955955', 'ai@gmail.com', '20/3/2000', 'female', ''),
(6, 'aa', 'a', 'asn@gnai@@123.com', '12-23-2000', 'female', ''),
(7, 'aa', 'a', 'a', 'a', 'male', ''),
(8, 'a', '9784561230', 'ah@gmail.com', '2000-03-20', 'female', '');

-- --------------------------------------------------------

--
-- Table structure for table `worker`
--

CREATE TABLE `worker` (
  `id` int(100) NOT NULL,
  `f_name` varchar(255) NOT NULL,
  `l_name` varchar(255) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `email` varchar(255) NOT NULL,
  `question` varchar(255) NOT NULL,
  `answer` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `worker`
--

INSERT INTO `worker` (`id`, `f_name`, `l_name`, `phone`, `email`, `question`, `answer`, `password`) VALUES
(1, 'sumanth', '', '9481235612', 'sum@1gmail.com', '', '', ''),
(2, 'abc', '', '156', 'abc@gmail.com', 'Your best friend name', 'abc', '156'),
(3, 'sumanth kumar ', 's', '9486512352', 'sum@gmail.com', 'Your First Pet Name', 'hell', '1234'),
(4, 'a', '', '7854856932', 'a@gmail.com', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `workermanage`
--

CREATE TABLE `workermanage` (
  `id` int(100) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `gender` varchar(100) NOT NULL,
  `phone` varchar(100) DEFAULT NULL,
  `dob` varchar(100) DEFAULT current_timestamp(),
  `address` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `workermanage`
--

INSERT INTO `workermanage` (`id`, `name`, `email`, `gender`, `phone`, `dob`, `address`) VALUES
(1, 'sumanth', '', 'Male', '9481235612', '20/3/2000', 'manglore\n'),
(2, 'sumanth kumar s', '', 'Male', '9481235612', '20/5/2000', 'manglore'),
(3, 'abc', '', 'Male', '9864567895', '15/10/1999', 'banglore'),
(4, 'a', '', 'Female', '7854856932', '8/3/2000', 'udupi\n');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `patient_details`
--
ALTER TABLE `patient_details`
  ADD PRIMARY KEY (`patient_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_info`
--
ALTER TABLE `user_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `worker`
--
ALTER TABLE `worker`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `workermanage`
--
ALTER TABLE `workermanage`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `patient_details`
--
ALTER TABLE `patient_details`
  MODIFY `patient_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `user_info`
--
ALTER TABLE `user_info`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `worker`
--
ALTER TABLE `worker`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `workermanage`
--
ALTER TABLE `workermanage`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
