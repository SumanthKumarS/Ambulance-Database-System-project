import mysql.connector

mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  password="",
  database="ambulance",
)
mycursor = mydb.cursor()
mycursor.execute("CREATE TABLE IF NOT EXISTS WORKER (id int(255),f_name VARCHAR(25),l_name VARCHAR(25),phone INT(10),email VARCHAR(25),dob DATE,gender VARCHAR(25),password VARCHAR(25))")

mycursor.execute("CREATE TABLE IF NOT EXISTS WORKER_MANAGE (worker_id int(25),name VARCHAR(25), phone INT(10),email VARCHAR(25),dob DATE,gender VARCHAR(25),address VARCHAR(25))")

mycursor.execute("CREATE TABLE IF NOT EXISTS USER (id int(25),f_name VARCHAR(25),l_name VARCHAR(25), phone INT(10),email VARCHAR(25),dob DATE,gender VARCHAR(25),password VARCHAR(25))")

mycursor.execute("CREATE TABLE IF NOT EXISTS USER_INFO (user_id int(25),name VARCHAR(25), phone INT(10),email VARCHAR(25),dob DATE,gender VARCHAR(25),address VARCHAR(25))")

mycursor.execute("CREATE TABLE IF NOT EXISTS REQUEST_ACCEPT (id VARCHAR(25),name VARCHAR(25),email VARCHAR(25),latitude VARCHAR(25),longitude VARCHAR(25),state VARCHAR(25),city VARCHAR(25),reqst_accept VARCHAR(25),date DATE,time TIME)")

mycursor.execute("CREATE TABLE IF NOT EXISTS REQUEST_ACCEPT (id VARCHAR(25),name VARCHAR(25),email VARCHAR(25),latitude VARCHAR(25),longitude VARCHAR(25),state VARCHAR(25),city VARCHAR(25),reqst_accept VARCHAR(25),date DATE,time TIME)")

mycursor.execute("CREATE TABLE IF NOT EXISTS REQUEST_DETAILS (id VARCHAR(25),name VARCHAR(25),email VARCHAR(25),latitude VARCHAR(25),longitude VARCHAR(25),state VARCHAR(25),city VARCHAR(25),reqst_accept VARCHAR(25),date DATE,time TIME)")

mycursor.execute("CREATE TABLE IF NOT EXISTS PATIENT_DETAILS (PNO INT(25),name VARCHAR(25),email VARCHAR(25),phone INT(10),address VARCHAR(25),place VARCHAR(25),date_time DATETIME)")

#mycursor.execute("SELECT * FROM worker")

#mycursor.execute("SELECT * FROM user")

#mycursor.execute("SELECT * FROM worker_manage ")

print(mycursor.fetchall())

#print(r2.fetchall())

#mycursor.execute("SHOW DATABASES")

"""for x in mycursor:
  print(x)
"""
